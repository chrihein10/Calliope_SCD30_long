# scd30 package

MakeCode blocks for the scd30 environment sensor

Package for the (Grove) Sensirion SCD30 CO2 sensor (https://www.seeedstudio.com/Grove-CO2-Temperature-Humidity-Sensor-SCD30-p-2911.html).
Detects CO2 concentration, temperature and humidity.

## License

MIT
